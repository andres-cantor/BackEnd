document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');

    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();

        // Obtener los valores del formulario
        const formData = {
            nombre: document.getElementById('nombre').value,
            apellido: document.getElementById('apellido').value,
            correo: document.getElementById('correo').value,
            pais: document.getElementById('pais').value,
            telefono: document.getElementById('telefono').value,
            asunto: document.getElementById('asunto').value
        };

        // Validar los datos
        if (validarDatos(formData)) {
            // Procesar los datos
            procesarFormulario(formData);
            // Limpiar el formulario
            loginForm.reset();
        }
    });

    // Función para validar los datos
    function validarDatos(data) {
        // Validar que ningún campo esté vacío
        for (let key in data) {
            if (!data[key]) {
                alert(`Por favor, complete el campo ${key}`);
                return false;
            }
        }

        // Validar formato de correo
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(data.correo)) {
            alert('Por favor, ingrese un correo electrónico válido');
            return false;
        }

        // Validar formato de teléfono (números y algunos caracteres especiales)
        const phoneRegex = /^[0-9+\-\s()]+$/;
        if (!phoneRegex.test(data.telefono)) {
            alert('Por favor, ingrese un número de teléfono válido');
            return false;
        }

        return true;
    }

    // Función para procesar el formulario
    function procesarFormulario(data) {
        // Aquí puedes agregar la lógica para enviar los datos al servidor
        console.log('Datos del formulario:', data);
        
        // Mostrar mensaje de éxito
        alert('Formulario enviado con éxito');
        
        // Cerrar el acordeón después de enviar (si usas Bootstrap)
        const accordionButton = document.querySelector('[data-bs-toggle="collapse"]');
        const bsCollapse = bootstrap.Collapse.getInstance(document.getElementById('loginAccordion'));
        if (bsCollapse) {
            bsCollapse.hide();
        }
    }

    // Validación en tiempo real de los campos
    const inputs = loginForm.querySelectorAll('input');
    inputs.forEach(input => {
        input.addEventListener('input', function() {
            if (this.value.trim() === '') {
                this.classList.add('invalid');
            } else {
                this.classList.remove('invalid');
            }
        });
    });
}); 





































// Manejo del formulario
document.getElementById('commentForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const userName = document.getElementById('userName').value;
    const topic = document.getElementById('topicSelect').value;
    const comment = document.getElementById('userComment').value;
    
    // Crear nuevo comentario
    const newComment = createCommentCard(userName, topic, comment);
    
    // Agregar al inicio de la lista
    const commentsList = document.querySelector('.comments-list');
    commentsList.insertBefore(newComment, commentsList.firstChild);
    
    // Limpiar formulario
    this.reset();
});

// Función para crear tarjeta de comentario
function createCommentCard(userName, topic, comment) {
    const date = new Date().toLocaleDateString();
    
    const commentCard = document.createElement('div');
    commentCard.className = 'comment-card';
    commentCard.innerHTML = `
        <div class="comment-header">
            <div class="user-info">
                <img src="default-avatar.png" alt="Usuario" class="user-avatar">
                <div class="user-details">
                    <h4>${userName}</h4>
                    <span class="comment-date">${date}</span>
                </div>
            </div>
            <span class="comment-topic">${topic}</span>
        </div>
        <div class="comment-content">
            <p>${comment}</p>
        </div>
        <div class="comment-actions">
            <button class="like-btn"><i class="fas fa-heart"></i> <span>0</span></button>
            <button class="reply-btn"><i class="fas fa-reply"></i> Responder</button>
        </div>
    `;
    
    return commentCard;
}























// Manejo de likes
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('like-btn')) {
        const likeCount = e.target.querySelector('span');
        likeCount.textContent = parseInt(likeCount.textContent) + 1;
    }
});

// Filtrado de comentarios
document.getElementById('filterComments').addEventListener('change', function(e) {
    const filter = e.target.value;
    const comments = document.querySelectorAll('.comment-card');
    
    comments.forEach(comment => {
        const topic = comment.querySelector('.comment-topic').textContent.toLowerCase();
        if (filter === 'all' || topic === filter) {
            comment.style.display = 'block';
        } else {
            comment.style.display = 'none';
        }
    });
}); 







// COSUMO DE API
// URL base del backend
const apiUrl = 'http://127.0.0.1:8000/api/foros/';

// Realizar la solicitud GET a /api/
fetch(apiUrl)
  .then(response => {
    // Verificamos si la respuesta es exitosa
    if (!response.ok) {
        throw new Error('Error en la solicitud: ' + response.status);
    }
    return response.json(); // Parseamos la respuesta a formato JSON
  })
  .then(data => {
    // Accedemos a los datos JSON
    console.log(data); // Mostramos los datos en la consola

    // Ahora puedes acceder a las URLs específicas desde el objeto JSON
    const forosUrl = data.foros;
    console.log("URL de Foros:", forosUrl);

    // Aquí puedes hacer otra solicitud a la URL de "foros" si deseas obtener más información.
    return fetch(forosUrl);
  })
  .then(response => response.json())
  .then(foroData => {
    // Aquí procesamos los datos de los "foros"
    console.log(foroData); // Muestra los datos de los foros
    // Aquí puedes hacer lo que necesites con los datos de los foros
  })
  .catch(error => {
    console.error('Hubo un problema con la solicitud:', error);
  });








