// Esperar a que el DOM esté completamente cargado
document.addEventListener('DOMContentLoaded', function() {
    // Obtener el formulario
    const commentForm = document.getElementById('commentForm');
    const commentsList = document.querySelector('.comments-list');

    // Manejar el envío del formulario
    commentForm.addEventListener('submit', function(e) {
        e.preventDefault(); // Prevenir el envío tradicional del formulario

        // Obtener los valores del formulario
        const userName = document.getElementById('userName').value;
        const topic = document.getElementById('topicSelect').value;
        const comment = document.getElementById('userComment').value;

        // Validar que los campos no estén vacíos
        if (!userName || !topic || !comment) {
            alert('Por favor, completa todos los campos');
            return;
        }

        // Crear el nuevo comentario
        const currentDate = new Date().toLocaleDateString('es-ES', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });

        // HTML del nuevo comentario
        const newCommentHTML = `
            <div class="comment-card" data-topic="${topic.toLowerCase()}">
                <div class="comment-header">
                    <div class="user-info">
                        <img src="https://ui-avatars.com/api/?name=${encodeURIComponent(userName)}&background=random" 
                             alt="${userName}" 
                             class="user-avatar">
                        <div class="user-details">
                            <h4>${userName}</h4>
                            <span class="comment-date">${currentDate}</span>
                        </div>
                    </div>
                    <div class="comment-controls">
                        <span class="comment-topic">${topic}</span>
                        <button class="delete-btn" onclick="deleteComment(this)" title="Eliminar comentario">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
                <div class="comment-content">
                    <p>${comment}</p>
                </div>
                <div class="comment-actions">
                    <button class="like-btn" onclick="handleLike(this)">
                        <i class="fas fa-heart"></i> <span>0</span>
                    </button>
                    <button class="reply-btn" onclick="handleReply(this)">
                        <i class="fas fa-reply"></i> Responder
                    </button>
                </div>
            </div>
        `;

        // Insertar el nuevo comentario al principio de la lista
        commentsList.insertAdjacentHTML('afterbegin', newCommentHTML);

        // Animar la entrada del nuevo comentario
        const newComment = commentsList.firstElementChild;
        newComment.style.animation = 'slideIn 0.5s ease-out';

        // Limpiar el formulario
        commentForm.reset();

        // Mostrar mensaje de éxito
        showNotification('¡Comentario publicado con éxito!');
    });
});

// Función para manejar los likes
function handleLike(button) {
    const likeCount = button.querySelector('span');
    const currentLikes = parseInt(likeCount.textContent);
    likeCount.textContent = currentLikes + 1;
    
    // Animar el botón de like
    button.classList.add('liked');
    setTimeout(() => button.classList.remove('liked'), 300);
}

// Función para manejar las respuestas
function handleReply(button) {
    const commentCard = button.closest('.comment-card');
    const userName = commentCard.querySelector('.user-details h4').textContent;
    
    // Scroll hasta el formulario
    document.getElementById('commentForm').scrollIntoView({ behavior: 'smooth' });
    
    // Pre-llenar el área de comentario con una referencia
    const commentArea = document.getElementById('userComment');
    commentArea.value = `@${userName} `;
    commentArea.focus();
}

// Función para mostrar notificaciones
function showNotification(message) {
    // Crear elemento de notificación
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.textContent = message;
    
    // Agregar al DOM
    document.body.appendChild(notification);
    
    // Animar entrada
    setTimeout(() => notification.classList.add('show'), 100);
    
    // Remover después de 3 segundos
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Función para eliminar comentarios
function deleteComment(button) {
    const commentCard = button.closest('.comment-card');
    
    // Mostrar diálogo de confirmación
    if (confirm('¿Estás seguro de que deseas eliminar este comentario?')) {
        // Animación de salida
        commentCard.style.animation = 'slideOut 0.5s ease-out';
        
        // Esperar a que termine la animación antes de eliminar
        setTimeout(() => {
            commentCard.remove();
            showNotification('Comentario eliminado');
        }, 500);
    }
} 