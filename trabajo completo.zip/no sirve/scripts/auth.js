document.addEventListener('DOMContentLoaded', function() {
    // Elementos del DOM
    const modal = document.getElementById('registroModal');
    const registroForm = document.getElementById('registroForm');
    const usersAccordion = document.getElementById('usersAccordion');
    
    // Obtener usuarios guardados
    let users = JSON.parse(localStorage.getItem('users') || '[]');

    // Función para abrir el modal
    window.openRegistroModal = function() {
        modal.style.display = 'block';
        updateUsersDisplay();
    }

    // Función para mostrar el formulario
    window.showRegisterForm = function() {
        registroForm.style.display = 'block';
        registroForm.scrollIntoView({ behavior: 'smooth' });
    }

    // Manejar el registro de usuarios
    registroForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const username = document.getElementById('newUsername').value;
        const password = document.getElementById('newPassword').value;

        // Crear nuevo usuario
        const newUser = {
            id: Date.now(),
            username: username,
            password: password,
            dateCreated: new Date().toLocaleString()
        };

        // Agregar al array de usuarios
        users.push(newUser);
        
        // Guardar en localStorage
        localStorage.setItem('users', JSON.stringify(users));
        
        // Actualizar display
        updateUsersDisplay();
        
        // Limpiar y ocultar formulario
        registroForm.reset();
        registroForm.style.display = 'none';
        
        // Mostrar mensaje de éxito
        showNotification('Usuario registrado exitosamente');
    });

    // Función para actualizar la visualización de usuarios
    function updateUsersDisplay() {
        usersAccordion.innerHTML = users.map(user => `
            <div class="user-item" data-id="${user.id}">
                <div class="user-header" onclick="toggleUserDetails(${user.id})">
                    <span>${user.username}</span>
                    <i class="fas fa-chevron-down"></i>
                </div>
                <div class="user-content" id="user-${user.id}">
                    <p><strong>Usuario:</strong> ${user.username}</p>
                    <p><strong>Contraseña:</strong> ${'•'.repeat(user.password.length)}</p>
                    <p><strong>Fecha de registro:</strong> ${user.dateCreated}</p>
                    <button onclick="deleteUser(${user.id})" class="delete-btn">
                        <i class="fas fa-trash"></i> Eliminar
                    </button>
                </div>
            </div>
        `).join('');
    }

    // Función para mostrar/ocultar detalles de usuario
    window.toggleUserDetails = function(userId) {
        const content = document.getElementById(`user-${userId}`);
        content.classList.toggle('active');
    }

    // Función para eliminar usuario
    window.deleteUser = function(userId) {
        if (confirm('¿Estás seguro de que deseas eliminar este usuario?')) {
            users = users.filter(user => user.id !== userId);
            localStorage.setItem('users', JSON.stringify(users));
            updateUsersDisplay();
            showNotification('Usuario eliminado exitosamente');
        }
    }

    // Función para mostrar notificaciones
    function showNotification(message) {
        const notification = document.createElement('div');
        notification.className = 'notification';
        notification.textContent = message;
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 3000);
    }

    // Cerrar modal
    document.querySelector('.close').onclick = function() {
        modal.style.display = 'none';
    }

    // Cerrar al hacer clic fuera
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = 'none';
        }
    }
});