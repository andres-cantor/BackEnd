document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.querySelector('.login-form');
    const dropbtn = document.querySelector('.dropbtn');
    const dropdownContent = document.querySelector('.dropdown-content');
    const togglePassword = document.querySelector('.toggle-password');
    const passwordInput = document.getElementById('password');

    // Manejar envío del formulario
    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const username = document.getElementById('username').value;
        const password = passwordInput.value;

        try {
            // Aquí iría tu lógica de autenticación
            if (username && password) {
                // Simular login exitoso
                const userData = { username };
                localStorage.setItem('currentUser', JSON.stringify(userData));
                updateUIForLoggedUser(username);
                showNotification('¡Inicio de sesión exitoso!');
            } else {
                throw new Error('Por favor complete todos los campos');
            }
        } catch (error) {
            showNotification(error.message, 'error');
        }
    });

    // Mostrar/Ocultar contraseña
    togglePassword.addEventListener('click', () => {
        const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
        passwordInput.setAttribute('type', type);
        togglePassword.classList.toggle('fa-eye');
        togglePassword.classList.toggle('fa-eye-slash');
    });

    // Actualizar UI para usuario logueado
    function updateUIForLoggedUser(username) {
        dropdownContent.innerHTML = `
            <div class="user-info">
                <h3>Bienvenido, ${username}</h3>
                <button class="logout-btn">Cerrar Sesión</button>
            </div>
        `;
        dropbtn.textContent = username;

        // Agregar evento al botón de cerrar sesión
        const logoutBtn = dropdownContent.querySelector('.logout-btn');
        logoutBtn.addEventListener('click', handleLogout);
    }

    // Manejar cierre de sesión
    function handleLogout() {
        localStorage.removeItem('currentUser');
        location.reload();
    }

    // Verificar sesión al cargar
    function checkSession() {
        const savedUser = localStorage.getItem('currentUser');
        if (savedUser) {
            const { username } = JSON.parse(savedUser);
            updateUIForLoggedUser(username);
        }
    }

    // Mostrar notificaciones
    function showNotification(message, type = 'success') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        document.body.appendChild(notification);

        setTimeout(() => {
            notification.classList.add('show');
        }, 100);

        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    }

    // Verificar sesión al cargar la página
    checkSession();
}); 