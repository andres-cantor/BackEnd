document.addEventListener('DOMContentLoaded', function() {
    const loginToggle = document.querySelector('.login-toggle');
    const loginDropdown = document.querySelector('.login-dropdown');
    const loginForm = document.querySelector('.login-form');
    const togglePassword = document.querySelector('.toggle-password');
    const passwordInput = document.getElementById('password');

    // Mostrar/Ocultar dropdown
    loginToggle.addEventListener('click', (e) => {
        e.stopPropagation();
        loginDropdown.classList.toggle('active');
    });

    // Cerrar al hacer clic fuera
    document.addEventListener('click', (e) => {
        if (!loginDropdown.contains(e.target) && !loginToggle.contains(e.target)) {
            loginDropdown.classList.remove('active');
        }
    });

    // Mostrar/Ocultar contraseña
    togglePassword.addEventListener('click', () => {
        const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
        passwordInput.setAttribute('type', type);
        togglePassword.classList.toggle('fa-eye');
        togglePassword.classList.toggle('fa-eye-slash');
    });

    // Manejar envío del formulario
    loginForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const username = document.getElementById('username').value;
        const password = passwordInput.value;

        // Aquí irían las validaciones y el envío al servidor
        console.log('Iniciando sesión...', { username, password });

        // Simular éxito
        showNotification('¡Inicio de sesión exitoso!');
        loginDropdown.classList.remove('active');
        loginForm.reset();
    });

    // Función para mostrar notificaciones
    function showNotification(message) {
        const notification = document.createElement('div');
        notification.className = 'notification';
        notification.textContent = message;
        document.body.appendChild(notification);

        setTimeout(() => {
            notification.classList.add('show');
        }, 100);

        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    }
}); 